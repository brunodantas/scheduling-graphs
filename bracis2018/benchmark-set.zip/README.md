Multiprocessor task scheduling graphs used as a benchmark in our BRACIS paper.
